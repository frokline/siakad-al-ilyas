<?php

namespace App\Services;

use App\Models\Role;
use App\Models\User;

final class TujuanPortal
{
    public function namaRoute(User $user): ?string
    {
        $user = User::query()
            ->with(['roles:id,kode', 'dosen:id,user_id,status', 'mahasiswa:id,user_id'])
            ->whereKey($user->getAuthIdentifier())
            ->where('status', User::STATUS_AKTIF)
            ->first();

        if (! $user) {
            return null;
        }

        $peran = $user->roles->pluck('kode');

        if ($peran->contains(Role::ADMIN_AKADEMIK)) {
            return 'admin.roles.index';
        }

        if ($peran->contains(Role::ADMIN_KEUANGAN)) {
            return 'keuangan.jenis-biaya.index';
        }

        if (
            $peran->contains(Role::DOSEN)
            && $user->dosen
            && $user->dosen->status === \App\Models\Dosen::AKTIF
        ) {
            return 'presensi.index';
        }

        if ($peran->contains(Role::MAHASISWA) && $user->mahasiswa) {
            return 'berkas.index';
        }

        return null;
    }

    public function dapatMasuk(User $user): bool
    {
        return $this->namaRoute($user) !== null;
    }
}
